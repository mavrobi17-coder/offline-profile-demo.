package com.example.offlineprofiledemo

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var nameField: EditText
    private lateinit var aboutField: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("profile", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 8)
        }
        val heading = TextView(this).apply {
            text = "Мой профиль"
            textSize = 28f
            setTextColor(Color.rgb(25, 50, 85))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }
        val subtitle = TextView(this).apply {
            text = "Работает без интернета. Данные хранятся на этом телефоне."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        nameField = EditText(this).apply {
            hint = "Имя"
            setSingleLine(true)
            setText(prefs.getString("name", ""))
        }
        aboutField = EditText(this).apply {
            hint = "О себе"
            minLines = 3
            gravity = Gravity.TOP
            setText(prefs.getString("about", ""))
        }
        val save = Button(this).apply {
            text = "Сохранить профиль"
            setOnClickListener {
                prefs.edit()
                    .putString("name", nameField.text.toString())
                    .putString("about", aboutField.text.toString())
                    .apply()
                status.text = "Профиль сохранён на устройстве."
                Toast.makeText(this@MainActivity, "Сохранено", Toast.LENGTH_SHORT).show()
            }
        }
        status = TextView(this).apply {
            text = "Ваши данные не отправляются в интернет."
            textSize = 14f
            setTextColor(Color.rgb(35, 110, 70))
            setPadding(0, 16, 0, 8)
        }
        content.addView(heading, matchWrap())
        content.addView(subtitle, matchWrap())
        content.addView(label("Имя"))
        content.addView(nameField, matchWrap())
        content.addView(label("О себе"))
        content.addView(aboutField, matchWrap())
        content.addView(save, matchWrap())
        content.addView(status, matchWrap())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 16f
        setTextColor(Color.rgb(40, 55, 75))
        setPadding(0, 12, 0, 0)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
